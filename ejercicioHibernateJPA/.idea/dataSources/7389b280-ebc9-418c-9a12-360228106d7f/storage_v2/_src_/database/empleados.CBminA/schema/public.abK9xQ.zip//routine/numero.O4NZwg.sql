create function numero() returns integer
    language plpgsql
as
$$
	BEGIN

	END;
$$;

alter function numero() owner to postgres;

